function plot_ean13_barcode_13digit(ean13)
    % Input: ean13 — a 13-digit string, e.g., '4006381333931'

    % Validate input
    if length(ean13) ~= 13 || any(~isstrprop(ean13, 'digit'))
        error('Input must be a 13-digit string');
    end

    % Encoding tables
    parity_patterns = {
        'LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', ...
        'LGLLGG', 'LGGLLG', 'LGGGLL', 'LGLGLG', ...
        'LGLGGL', 'LGGLGL'
    };

    L = {
        '0001101', '0011001', '0010011', '0111101', ...
        '0100011', '0110001', '0101111', '0111011', ...
        '0110111', '0001011'
    };

    G = {
        '0100111', '0110011', '0011011', '0100001', ...
        '0011101', '0111001', '0000101', '0010001', ...
        '0001001', '0010111'
    };

    R = {
        '1110010', '1100110', '1101100', '1000010', ...
        '1011100', '1001110', '1010000', '1000100', ...
        '1001000', '1110100'
    };

    % Parse digits
    first_digit = str2double(ean13(1));
    left_digits = double(ean13(2:7)) - '0';
    right_digits = double(ean13(8:13)) - '0';

    % Get parity pattern for left side
    parity = parity_patterns{first_digit + 1};

    % Guards
    start_guard = '101';
    middle_guard = '01010';
    end_guard = '101';

    % Build barcode pattern
    pattern = start_guard;
    for i = 1:6
        digit = left_digits(i);
        if parity(i) == 'L'
            pattern = [pattern L{digit + 1}];
        else
            pattern = [pattern G{digit + 1}];
        end
    end

    pattern = [pattern middle_guard];

    for i = 1:6
        digit = right_digits(i);
        pattern = [pattern R{digit + 1}];
    end

    pattern = [pattern end_guard];

    % Plot barcode using bar chart
    figure;
    hold on;
    axis off;

    for i = 1:length(pattern)
        if pattern(i) == '1'
            bar(i, 1, 'k');
        end
    end

    xlim([0 length(pattern)+1]);
    ylim([0 1.2]);
    title(['EAN-13: ', ean13]);
end
