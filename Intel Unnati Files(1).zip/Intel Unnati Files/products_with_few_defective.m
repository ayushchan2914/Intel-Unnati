clear all;clc;

% Number of barcodes to generate
numBarcodes = 150;

% Function to compute EAN-13 checksum digit
computeEAN13Checksum = @(digits) mod(10 - mod(sum(digits(1:2:end)) + 3 * sum(digits(2:2:end)), 10), 10);

% Generate 12-digit numbers and compute checksum
ean13Barcodes = strings(numBarcodes, 1);
for i = 1:numBarcodes
    digits12 = randi([0 9], 1, 12); % 12 random digits
    checksum = computeEAN13Checksum(digits12);
    fullDigits = [digits12 checksum]; % Append checksum
    ean13Barcodes(i) = join(string(fullDigits), "");
end

% Batch assignment
batch1 = ean13Barcodes(1:50, :);
batch2 = ean13Barcodes(51:100, :);
batch3 = ean13Barcodes(101:150, :);

% Date range for manufacture
startDate = datetime(2025, 1, 1);
endDate = datetime(2025, 2, 28);
dateRange = days(endDate - startDate);
% Add random days AND random time (in fractional days)
batch1_date_of_manufacture = startDate + days(randi([0, dateRange], 50, 1)) + ...
                             hours(randi([0, 23], 50, 1)) + ...
                             minutes(randi([0, 59], 50, 1)) + ...
                             seconds(randi([0, 59], 50, 1));

% Repeat for batch2 and batch3
batch2_date_of_manufacture = startDate + days(randi([0, dateRange], 50, 1)) + ...
                             hours(randi([0, 23], 50, 1)) + ...
                             minutes(randi([0, 59], 50, 1)) + ...
                             seconds(randi([0, 59], 50, 1));

batch3_date_of_manufacture = startDate + days(randi([0, dateRange], 50, 1)) + ...
                             hours(randi([0, 23], 50, 1)) + ...
                             minutes(randi([0, 59], 50, 1)) + ...
                             seconds(randi([0, 59], 50, 1));
% Assign batch numbers
batch1_numbers = repmat("Batch 1", 50, 1);
batch2_numbers = repmat("Batch 2", 50, 1);
batch3_numbers = repmat("Batch 3", 50, 1);

% Generate random soap quality values
batch1_soap_quality = 85 + (100 - 85) * rand(50, 1);
batch2_soap_quality = 85 + (100 - 85) * rand(50, 1);
batch3_soap_quality = 85 + (100 - 85) * rand(50, 1);

% Generate random shampoo quality values
batch1_shampoo_quality = 70 + (100 - 70) * rand(50, 1);
batch2_shampoo_quality = 70 + (100 - 70) * rand(50, 1);
batch3_shampoo_quality = 70 + (100 - 70) * rand(50, 1);
% Generate random toothpaste quality values
batch1_toothpaste_quality = 60 + (100 - 60) * rand(50, 1);
batch2_toothpaste_quality = 60 + (100 - 60) * rand(50, 1);
batch3_toothpaste_quality = 60 + (100 - 60) * rand(50, 1);

% Combine toothpaste data
allToothpasteQuality = [batch1_toothpaste_quality; batch2_toothpaste_quality; batch3_toothpaste_quality];

% Randomly set a few very low toothpaste quality values (<10)
lowToothpasteIdx = randsample(150, 5);
allToothpasteQuality(lowToothpasteIdx) = rand(5, 1) * 10;

% Update headers and write to Excel with toothpaste quality
headers = {'Barcode', 'Date of Manufacture', 'Batch No.', 'Soap Quality', 'Shampoo Quality', 'Toothpaste Quality'};
writecell(headers, "Demo.xlsx", 'Sheet', 1, 'Range', 'A1');

% Write data including new toothpaste column
writematrix(allToothpasteQuality, "Demo.xlsx", 'Sheet', 1, 'Range', 'F2');


% Combine all data
allBarcodes = [batch1; batch2; batch3];
allDates = [batch1_date_of_manufacture; batch2_date_of_manufacture; batch3_date_of_manufacture];
allBatchNumbers = [batch1_numbers; batch2_numbers; batch3_numbers];
allSoapQuality = [batch1_soap_quality; batch2_soap_quality; batch3_soap_quality];
allShampooQuality = [batch1_shampoo_quality; batch2_shampoo_quality; batch3_shampoo_quality];
% Randomly set a few very low quality values (<10)
numLow = 5;
lowSoapIdx = randsample(150, numLow);
lowShampooIdx = randsample(150, numLow);

allSoapQuality(lowSoapIdx) = rand(numLow, 1) * 10;
allShampooQuality(lowShampooIdx) = rand(numLow, 1) * 10;
% Write headers including Shampoo Quality
headers = {'Barcode', 'Date of Manufacture', 'Batch No.', 'Soap Quality', 'Shampoo Quality'};
writecell(headers, "Demo.xlsx", 'Sheet', 1, 'Range', 'A1');

% Write data to Excel
writecell(cellstr(allBarcodes), "Demo.xlsx", 'Sheet', 1, 'Range', 'A2');
writematrix(allDates, "Demo.xlsx", 'Sheet', 1, 'Range', 'B2');
writecell(cellstr(allBatchNumbers), "Demo.xlsx", 'Sheet', 1, 'Range', 'C2');
writematrix(allSoapQuality, "Demo.xlsx", 'Sheet', 1, 'Range', 'D2');
writematrix(allShampooQuality, "Demo.xlsx", 'Sheet', 1, 'Range', 'E2');

set(0, 'DefaultFigureVisible', 'off');  % Suppress all figure display

outputFolder = "BarcodeImages";
if ~exist(outputFolder, 'dir')
    mkdir(outputFolder);
end

for i = 1:numBarcodes
     % No need for 'Visible','off' — already globally suppressed
    plot_ean13_barcode(char(ean13Barcodes(i)));
    filename = fullfile(outputFolder, sprintf('barcode_%03d.png', i));
    exportgraphics(gcf, filename, 'Resolution', 300);
end

set(0, 'DefaultFigureVisible', 'on');  % Restore default behavior